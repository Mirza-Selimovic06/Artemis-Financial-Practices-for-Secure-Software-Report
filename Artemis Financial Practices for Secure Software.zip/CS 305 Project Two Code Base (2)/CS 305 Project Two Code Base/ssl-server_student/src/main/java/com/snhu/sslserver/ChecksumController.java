package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChecksumController {

    private static String sha256Hex(String data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(data.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(digest.length * 2);
        for (byte b : digest) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private static boolean verify(String data, String expectedHex) throws NoSuchAlgorithmException {
        byte[] actual = sha256Hex(data).getBytes(StandardCharsets.UTF_8);
        byte[] expected = expectedHex.getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(actual, expected);
    }

    @GetMapping("/hash")
    public String hash() {
        String data = "Hello World Check Sum! - Mirza Selimovic - CS305-1018-xyz";
        try {
            String checksum = sha256Hex(data);
            boolean valid = verify(data, checksum);
            return "<p>data: " + data + "</p>"
                 + "<p>Algorithm: SHA-256</p>"
                 + "<p>Checksum: " + checksum + "</p>"
                 + "<p>Verified: " + valid + "</p>";
        } catch (NoSuchAlgorithmException e) {
            return "Checksum could not be generated.";
        }
    }
}